#Jorge Castro 12/22/2020
#This script will parse curl response and create a block header

#  "version" : n,                    (numeric) The preferred block version
#  "previousblockhash" : "xxxx",     (string) The hash of current highest block
#  "curtime" : ttt,                  (numeric) current timestamp in seconds since epoch (Jan 1 1970 GMT)
#  "bits" : "xxxxxxxx",              (string) compressed target of next block


import json
import hashlib
import binascii


def lilendian(string):
    ba = bytearray.fromhex(string)
    ba.reverse()
    s = ''.join(format(x, '02x') for x in ba)
    return s


with open('output.json') as f:
  data = json.load(f)

pairs = []


for x in range(0,len(data['transactions']),2):
    if x < len(data['transactions'])-1:
        id1 = data['transactions'][x]['hash']
        id2 = data['transactions'][x+1]['hash']
        id12 = id1+id2
        first_hash = hashlib.sha256(binascii.unhexlify(id12)).hexdigest()
        second_hash = hashlib.sha256(binascii.unhexlify(first_hash)).hexdigest()
        pairs.append(second_hash)

tx1234 = pairs[0]+pairs[1]
first_hash = hashlib.sha256(binascii.unhexlify(tx1234)).hexdigest()
second_hash = hashlib.sha256(binascii.unhexlify(first_hash)).hexdigest()

#little endian
version = lilendian((hex(data['version']))[2:])
merkelRoot = lilendian(second_hash)
previousblockhash = lilendian(data['previousblockhash'])
curtime = lilendian((hex((data['curtime'])))[2:])
bits = lilendian((hex(int((data['bits']),16)))[2:])

#blockheader
blockheader = version + merkelRoot + previousblockhash + curtime + bits

print(blockheader)
print(len(blockheader))








